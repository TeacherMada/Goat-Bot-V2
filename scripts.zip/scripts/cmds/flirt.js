
module.exports = {
	config: {
		name: "flirt",
		aliases: ["baby"],
		version: "1.0",
		author: "otineeeeeyyyyyyyyyyyy",
		role: 0,
		category: "fun",
		shortDescription: "Flirt With Lines",
		longDescription: "",
		guide: {
			vi: "Not Available",
			en: "{p} chik"
		} 
	},

	onStart: async function ({ api, event, userData, args }) {
			var mention = Object.keys(event.mentions)[0];
		if(!mention) return api.sendMessage("Need to tag 1 friend you want to fuck", event.threadID);
 let name =  event.mentions[mention];
		var arraytag = []; 
				arraytag.push({id: mention, tag: name});
		var a = function (a) { api.sendMessage(a, event.threadID); }
a("Sed why do you use this command <3 :3");
setTimeout(() => {a({body: "Hi there :3 :3" + " " + name, mentions: arraytag})}, 2000);
setTimeout(() => {a({body: "Your breasts are so pretty, you're pretty too" + " " + name, mentions: arraytag})}, 3000);
setTimeout(() => {a({body: "I'll give you one." + " " + name, mentions: arraytag})}, 4000);
setTimeout(() => {a({body: "It's okay if I bust your dick for a bit :<" + " " + name, mentions: arraytag})}, 5000);
setTimeout(() => {a({body: "Looking at you makes me so hot :<" + " " + name, mentions: arraytag})}, 6000);
setTimeout(() => {a({body: "Just let me do one lol" + " " + name, mentions: arraytag})}, 7000);
setTimeout(() => {a({body: "Agree to let me fuck you :3" + " " + name, mentions: arraytag})}, 8000);
setTimeout(() => {a({body: "I promise I'll make you happy." + " " + name, mentions: arraytag})}, 9000);
setTimeout(() => {a({body: "Just for one night, baby" + " " + name, mentions: arraytag})}, 10000);
setTimeout(() => {a({body: "Let me put my dick in your pussy" + " " + name, mentions: arraytag})}, 11000);
setTimeout(() => {a({body: "I love you, so let me fuck you <3" + " " + name, mentions: arraytag})}, 12000);
setTimeout(() => {a({body: "Fuck 1 shot and I'm addicted" + " " + name, mentions: arraytag})}, 13000);
setTimeout(() => {a({body: "I'm sure you'll make me fall in love with your cock" + " " + name, mentions: arraytag})}, 14000);
setTimeout(() => {a({body: "So let me fuck one" + " " + name, mentions: arraytag})}, 15000);
setTimeout(() => {a({body: "Wait a minute, I took out a condom to fuck you" + " " + name, mentions: arraytag})}, 16000);
setTimeout(() => {a({body: "Oce condom is here" + " " + name, mentions: arraytag})}, 17000);
setTimeout(() => {a({body: "Let's go to bed to fuck each other" + " " + name, mentions: arraytag})}, 18000);
setTimeout(() => {a({body: "I'll take my clothes off." + " " + name, mentions: arraytag})}, 19000);
setTimeout(() => {a({body: "Let me undress." + " " + name, mentions: arraytag})}, 20000);
setTimeout(() => {a({body: "Let me put my dick in your pussy" + " " + name, mentions: arraytag})}, 21000);
setTimeout(() => {a("What the fuck is that wide?")} , 22000);
setTimeout(() => {a({body: "Well let me do it" + " " + name, mentions: arraytag})}, 23000);
setTimeout(() => {a({body: "I love you but your pussy is too wide" + " " + name, mentions: arraytag})}, 24000);
setTimeout(() => {a({body: "I'm sorry, but why do we treat each other like strangers?" + " " + name, mentions: arraytag})}, 25000);
setTimeout(() => {a("=)) I'm sorry I fucked you, but my dick isn't happy")} , 26000);
setTimeout(() => {a("Can i fuck you again :(")} , 27000);
setTimeout(() => {a("Your @$$ is so preety")} , 28000);
setTimeout(() => {a("Can i fuck it hardly")} , 29000);
setTimeout(() => {a("I will make kou satisfiying")} , 30000);
setTimeout(() => {a("Please babe don't say no :(")} , 31000);
setTimeout(() => {a("Let me hardly fuck you")} , 32000);
setTimeout(() => {a("Suss! don't cry someone is listening us")} , 33000);
setTimeout(() => {a("Thank for having fuck with me")} , 34000);
setTimeout(() => {a("Babe! i will come tommorow to fuck u again.. Okeyy!! :)")} , 35000);
	}
};